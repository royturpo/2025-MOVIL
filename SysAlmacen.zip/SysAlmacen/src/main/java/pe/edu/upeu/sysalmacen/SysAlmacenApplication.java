package pe.edu.upeu.sysalmacen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SysAlmacenApplication {

	public static void main(String[] args) {
		SpringApplication.run(SysAlmacenApplication.class, args);
	}

}
