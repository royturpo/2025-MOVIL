package pe.edu.upeu.sysalmacen.repositorio;

import pe.edu.upeu.sysalmacen.modelo.Cliente;

public interface IClienteRepository extends ICrudGenericoRepository<Cliente, String>{
}
