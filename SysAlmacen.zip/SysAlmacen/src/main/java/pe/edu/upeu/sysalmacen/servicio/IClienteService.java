package pe.edu.upeu.sysalmacen.servicio;

import pe.edu.upeu.sysalmacen.modelo.Cliente;

public interface IClienteService extends ICrudGenericoService<Cliente, String>{
}
